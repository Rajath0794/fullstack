const express = require("express");
const app = express();
const ejs = require('ejs')
const mongoose = require('mongoose')
mongoose.connect('mongodb+srv://rkadampanattu7459:test123@cluster0.dqordub.mongodb.net/testdatabase1?retryWrites=true&w=majority' , {useNewUrlParser:true})

app.set('view engine', 'ejs')
app.use(express.static('public'))
const G2 = require('./models/G2')
const bodyParser = require('body-parser')
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: true }))
app.listen(4000, () => {
  console.log("App listening on port 4000");
});
 
app.get('/', (req, res) => {
  res.render('index');
})

app.get('/g2', (req, res) => {
  res.render('g2_page');
})

app.get("/g", (req, res) => {
  res.render('g_page', { submitPressed: false, user: null });
})

app.get("/login", (req, res) => {
  res.render('login');
});

app.post("/g2/create", async (req, res) => {


  // async function main() {
  // Create Function
  try {
    const g2 = await G2.create(req.body)
    console.log(req.body);
    res.redirect('/');
  }
  catch (error) {
    console.log(error);
  }
  // }
  // main().catch(console.error)
});



app.get('/g/:id', async (req, res) => {
  const user = await G2.findById(req.params.id)
  res.render('g_page', { submitPressed: true, user });

})

app.post('/g2/update', async (req, res) => {
  console.log(req.body);
  const user = await G2.findByIdAndUpdate(req.body.id, {

    car_details: {
      make: req.body.make,
      model: req.body.model,
      year: req.body.year,
      pno: req.body.pno
    }

  });
  res.redirect('/g/' + req.body.id);

})

app.post('/g/find', async (req, res) => {
  const user = await G2.find({ license: req.body.licenseno });
  if (user.length > 0) {
    res.redirect('/g/' + user[0].id);
  }
  else {
    res.render('g_page', { user:null, submitPressed:true });
  }
})