module.exports =(req, res) => {
    //res.sendFile(path.resolve(__dirname,'public/login.html'))
    res.render('login');

}